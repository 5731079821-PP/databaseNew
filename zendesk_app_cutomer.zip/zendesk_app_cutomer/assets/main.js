$(function() {
	var client = ZAFClient.init();
	client.invoke('resize', { width: '100%', height: '160px' });
	callUser();
});

function callUser(){
	console.log('callUser');
	var user = $.get('https://zendesk-customer-proxy.us-e1.cloudhub.io/customers/194853').done(
		res => {
		display(res.data);
	}).fail(
		err => {
			console.log(err);
		}
	);	
}

function display(data) {
  var source = $("#requester-template").html();
  var template = Handlebars.compile(source);
  var html = template(data);
  $("#content").html(html)
}
