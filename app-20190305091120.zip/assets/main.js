$(function() {
	var client = ZAFClient.init();
	client.invoke('resize', { width: '100%', height: '160px' });
	client.get('ticket.requester.id').then(function(data) {
	  console.log(data['ticket.requester.id']); // something like 29043265
	});
	callApi(client);
});

function callApi(client) {
  var settings = {
    url: 'https://apigatewaydev.na.xom.com:4443/apps-smkt/customer/781921?sapSystem=EU',
    type:'GET',
    dataType: 'json',
  };

  var aCustomer;

  client.request(settings).then(
    function(data) {
      aCustomer = {
      	'name': data.CUST_NAME_2_ENG,
      	'soldTo': data.TRIMMED_LEGACY_CUST_NUM,
      	'segmemt': data.USTOMER_SEGMENTATION,
      	'accountGroup': data.CUST.ACCOUNT_GROUP,
      	'country': data.CUST.COUNTRY_NAME
      }
      display();
    },
    function(response) {
      console.error(response);
    }
  );
}


function display(data) {
  var source = $("#requester-template").html();
  var template = Handlebars.compile(source);
  var html = template(data);
  $("#content").html(html);
}
