$(function() {
	var client = ZAFClient.init();
	client.invoke('resize', { width: '100%', height: '160px' });
	client.get('ticket.requester.id').then(function(data) {
	  console.log(data['ticket.requester.id']); // something like 29043265
	});
	callApi(client);
  	showInfo();
  	
});

function showInfo() {

  var req_data = {
    'name': 'Yadava1',
    'tags': ['co-admin', 'support'],
    'created_at': 'Nov 26,2018',
    'last_login_at': 'Just now'
  };

  var scr = $("#requester-template").html();
  var template = Handlebars.compile(scr);
  var html = template(req_data);
  $("#content").html(html);

}

function callApi(client) {
  var settings = {
    url: 'https://jsonplaceholder.typicode.com/posts',
    type:'GET',
    dataType: 'json',
  };

  client.request(settings).then(
    function(data) {
      console.log(data);
      // display(data);
    },
    function(response) {
      console.error(response);
    }
  );
}


function display(data) {
  var requester_data = {
    'name': data.user.name,
    'tags': data.user.tags,
    'created_at': formatDate(data.user.created_at),
    'last_login_at': formatDate(data.user.last_login_at)
  };
  var source = $("#requester-template").html();
  var template = Handlebars.compile(source);
  var html = template(requester_data);
  $("#content").html(html);
}
