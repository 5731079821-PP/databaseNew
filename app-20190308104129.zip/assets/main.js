$(function() {
	var client = ZAFClient.init();
	client.invoke('resize', { width: '100%', height: '160px' });
	// getAccessToken();
	// callApi(client);
	callUser();
});

function callUser(){
	console.log('callUser');
	var user = $.get('https://jsonplaceholder.typicode.com/users');
	console.log(user);
	display(user);

}

// function getAccessToken(){

//   console.log('getAccessToken method');
//   var formData = new FormData();
//   formData.append('resource', 'eb590a5c-b7ba-44b5-acf5-2c40833a8283');
//   formData.append('grant_type', 'client_credentials');
//   formData.append('client_secret', 'wskaflN5Vcy+FCKUNovjhLptysakwL1/AThEnu5nyaQ=');
//   formData.append('client_id', '9790441b-d111-4c02-9027-131e1ba2fcf2');
//   var url = 'https://login.microsoftonline.com/d1ee1acd-bc7a-4bc4-a787-938c49a83906/oauth2/token';

//   var token = $.post(url, formData);
//   console.log(token);

// }

// function getToken(client) {


//   console.log('getToken method');
//   var formData = new FormData();
//   formData.append('resource', 'eb590a5c-b7ba-44b5-acf5-2c40833a8283');
//   formData.append('grant_type', 'client_credentials');
//   formData.append('client_secret', 'wskaflN5Vcy+FCKUNovjhLptysakwL1/AThEnu5nyaQ=');
//   formData.append('client_id', '9790441b-d111-4c02-9027-131e1ba2fcf2');
//   var u = 'https://login.microsoftonline.com/d1ee1acd-bc7a-4bc4-a787-938c49a83906/oauth2/token';
//   var settings = {
//     url: u,
//     type:'POST',
//     data: formData,
//     contentType: 'application/x-www-form-urlencoded; charset=utf-8'
//   };

//   var token;

//   client.request(u, ).then(
//     function(data) {
//     	console.log(data);
//     },
//     function(response) {
//    	  console.log('error');
//       console.error(response);
//     }
//   );
// }

// function callApi(client) {
//   var settings = {
//     url: 'https://apigatewaydev.na.xom.com:4443/apps-smkt/customer/781921?sapSystem=EU',
//     type:'GET',
//     dataType: 'json',
//     headers: {
//     	"Authorization":
//     		"Bearer "
//     }
//   };

//   var aCustomer;

//   client.request(settings).then(
//     function(data) {
//       aCustomer = {
//       	'name': data.CUST_NAME_2_ENG,
//       	'soldTo': data.TRIMMED_LEGACY_CUST_NUM,
//       	'segmemt': data.USTOMER_SEGMENTATION,
//       	'accountGroup': data.CUST.ACCOUNT_GROUP,
//       	'country': data.CUST.COUNTRY_NAME
//       }
//       display();
//     },
//     function(response) {
//       console.error(response);
//     }
//   );
// }



function display(data) {
  var source = $("#requester-template").html();
  var template = Handlebars.compile(source);
  var html = template(data);
  $("#content").html(html);
}
